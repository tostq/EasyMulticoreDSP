/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-y25
 */

#ifndef custom_vlfft_evmc6670l_core0__
#define custom_vlfft_evmc6670l_core0__



#endif /* custom_vlfft_evmc6670l_core0__ */ 
